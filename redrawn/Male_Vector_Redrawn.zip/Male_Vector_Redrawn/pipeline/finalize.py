from pathlib import Path
import json,re,zipfile,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';m=json.loads((OUT/'metrics.json').read_text())
ns={'s':'http://www.w3.org/2000/svg'}
results={}
for f in OUT.glob('*.svg'):
 r=ET.parse(f).getroot();paths=r.findall('.//s:path',ns);images=r.findall('.//s:image',ns)
 assert paths and not images
 for p in paths:
  nums=np.array([float(x) for x in re.findall(r'-?\d+(?:\.\d+)?',p.attrib['d'])]);assert np.isfinite(nums).all()
 assert r.attrib['viewBox']=='0 0 1024 1536'
 results[f.name]={'editable_paths_including_clip':len(paths),'embedded_images':len(images),'XML':'passed'}
preview=Image.open(OUT/'Male_Vector_Preview.png');assert preview.size==(3072,4608) and preview.mode=='RGBA';assert preview.getpixel((0,0))[3]==0
# Additional source/new-wire overlay documents redesign, not matching topology.
im=Image.open(ROOT/'source.png').convert('RGBA');bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);a=np.array(bg.convert('L'))
v=Image.open(ROOT/'Male_Wireframe_Only.png');b=Image.new('RGBA',v.size,'white');b.alpha_composite(v);b=np.array(b.convert('L').resize(im.size,Image.Resampling.LANCZOS));Image.fromarray(np.stack([b,a,a],axis=-1)).save(OUT/'Male_Vector_Overlay.png')
report=f'''# Smooth redrawn mannequin — delivery report

## Scope

The user authorized redesign of the linework after two raster-traced versions proved too uneven. This edition replaces the old wireframe with a deliberately drawn smooth grid. It is NOT an exact reconstruction of the AI-generated grid. Source: supplied 1024 × 1536 PNG. Body silhouette, pose, body-part sizes, and placement derive from that source; grid layout, density, and junctions are redesigned. No new raster-generated mannequin has been substituted.

## Files

- Male_Body_Master.svg — editable gray silhouette, smooth wireframe in named regional groups, independent outer contour and vector clipping.
- Male_Wireframe_Only.svg — linework and outer contour, transparent background.
- Male_Silhouette_Only.svg — independent closed gray silhouette, transparent background.
- Male_Vector_Preview.png — 3072 × 4608 transparent rendering of master.
- Male_Vector_Comparison.png — source and redrawn master, white background for inspection.
- Male_Vector_QA.png — enlarged head/neck, shoulders/torso, both hands, pelvis/thighs, knees and feet; original, master, and wireframe.
- Male_Vector_Overlay.png — red source/cyan new wire alignment overlay. The grids deliberately differ.
- Male_Silhouette_Overlay.png — source red/new cyan/overlap gray silhouette check.
- Male_Pelvis_Detail.png — enlarged new wireframe detail.

## Method

Body contour is taken from the PNG alpha channel, not the raster's dark wire lines. Pixel-edge coordinates are regularized with Gaussian smoothing along the contour (lower smoothing near head/hands/feet), then a periodic cubic spline with 0.22-pixel RMS smoothing target. This removes small staircase artifacts while keeping the figure's shape. Silhouette overlap with source, measured as mask intersection over union at source resolution: {m['silhouette_IoU']*100:.3f}%. This is an area-overlap measure, not a uniform pointwise error guarantee.

New linework uses source-based anatomical cross-section controls and continuous smooth surface coordinates. Head/jaw, neck/shoulders, chest/waist/pelvis, limbs and hands have separately designed flow. Adjacent shoulder grids share a seam. Arm and hand longitudes are joined with tangent-aligned connectors. A single hand surface replaces the overlapping palm/thumb grids tested earlier. Horizontal sections extend to the source-based clipping contour so they do not stop just short of the body edge. Leg surface sections derive from source alpha intervals and are smoothed. Feet and fingers retain the original silhouette but use simplified grid divisions.

Designed curves are approximated as cubic B-splines with a 0.07-pixel RMS smoothing target and converted exactly span-by-span to cubic SVG Beziers using spline positions and derivatives. This produces smooth curve continuity instead of tracing pixel steps. All SVG geometry remains editable. Line widths range from 0.6 to 0.9 source units. Fill is neutral #cdcdcd, strokes #242424. No shadows, gradients, text in the artwork, or visible raster images.

## Structure and counts

Named groups: 01_BODY_SILHOUETTE, 02_WIREFRAME_TORSO, 03_WIREFRAME_HEAD_NECK, 04_WIREFRAME_ARMS_HANDS, 05_WIREFRAME_LEGS_FEET, 06_OUTER_CONTOUR. Upper torso longitudes also pass through the neck and are kept continuous rather than split at that arbitrary region boundary.

Wireframe: {m['wireframe_paths']} paths, approximately {m['wireframe_anchors']} endpoint anchors. Silhouette: one closed path, approximately {m['silhouette_anchors']} anchors. The same silhouette geometry is reused for outline and non-visible clipping; those copies are not included in the unique geometry count. Bezier control handles are additional editable coordinates. Unlike revision 1/2, this edition does not contain thousands of short skeleton fragments.

## Validation

All three SVG files passed XML parsing, finite-coordinate checks and checks for absence of raster image elements. All three rendered successfully with CairoSVG. Preview transparency and its 3072 × 4608 dimensions passed. Enlarged visual review covered shoulders, wrist/hand transitions, pelvis/thighs, knees and feet. The redraw removed the source-tracing staircase effect and old tiny loops. QA images are from the final generation. ZIP integrity is checked after packaging. Validation results are included in validation.json.

## Practical limits

This is a stylized technical redraw, not a 3D model or exact original topology. The new grid is intentionally more regular and less anatomically detailed, particularly at hands, toes, face, chest and knees. Outer-contour smoothing causes small local differences from the PNG. The source retains its original pose and asymmetric outline, while most new paired-limb grid controls are approximately mirrored. At dense cap regions such as fingertips and shoulder origins, lines converge deliberately.

Adobe Illustrator opening/editing has NOT been tested because Illustrator is not installed. SVG uses standard editable paths, groups and clipPath; verify stroke/clipping import when opening it in Illustrator. Group names may import as groups rather than native Illustrator layers. Save the imported file as .ai for native Illustrator work.

## Reproduction

The ZIP includes source.png, redraw.py, finalize.py and pinned requirements.txt in pipeline/. From that directory, run `python3 -m pip install -r requirements.txt`, `python3 redraw.py`, then `python3 finalize.py`. Dependencies and rendering are installed and tested in the current environment. No live services or credentials are required.
'''
(OUT/'Vectorization_Report.md').write_text(report)
(OUT/'validation.json').write_text(json.dumps({'SVGs':results,'transparent_preview':'passed','preview_size':preview.size},indent=2))
(ROOT/'requirements.txt').write_text('numpy==2.3.5\nscipy==1.17.0\nPillow==12.3.0\nscikit-image==0.26.0\nopencv-python-headless==5.0.0.93\nCairoSVG==2.9.1\n')
with zipfile.ZipFile(ROOT/'Male_Vector_Redrawn.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(OUT.iterdir()):z.write(f,'Male_Vector_Redrawn/'+f.name)
 for name in ['source.png','redraw.py','finalize.py','requirements.txt']:z.write(ROOT/name,'Male_Vector_Redrawn/pipeline/'+name)
with zipfile.ZipFile(ROOT/'Male_Vector_Redrawn.zip') as z:assert z.testzip() is None
print(json.dumps(results,indent=2));print('ZIP integrity passed:',(ROOT/'Male_Vector_Redrawn.zip').stat().st_size,'bytes')
