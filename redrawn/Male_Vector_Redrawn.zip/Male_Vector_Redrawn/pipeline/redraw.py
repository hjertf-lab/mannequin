from pathlib import Path
import json, numpy as np, cv2, cairosvg
from PIL import Image,ImageDraw,ImageFont
from scipy.interpolate import CubicSpline, PchipInterpolator, splprep, BSpline
from scipy.ndimage import gaussian_filter1d
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
im=Image.open(ROOT/'source.png').convert('RGBA');W,H=im.size;arr=np.array(im)
bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);source=bg.convert('RGB')
alpha=arr[:,:,3]>128
from skimage.measure import find_contours
loops=find_contours(np.pad(alpha,1),.5)
cont=max(loops,key=len)[:,::-1]-.5
# Match pixel-edge coordinates in SVG; regularize only raster-scale steps.
fine=(cont[:,1]<220)|(cont[:,1]>1340)|((cont[:,1]>690)&(cont[:,1]<845)&((cont[:,0]<330)|(cont[:,0]>690)))
weight=gaussian_filter1d(fine.astype(float),8,mode='wrap')[:,None]
cont=weight*gaussian_filter1d(cont,2.2,axis=0,mode='wrap')+(1-weight)*gaussian_filter1d(cont,6.5,axis=0,mode='wrap')
cont=np.vstack([cont,cont[0]])
groups={n:[] for n in ['01_BODY_SILHOUETTE','02_WIREFRAME_TORSO','03_WIREFRAME_HEAD_NECK','04_WIREFRAME_ARMS_HANDS','05_WIREFRAME_LEGS_FEET','06_OUTER_CONTOUR']}
counts={};curves=[]
def fmt(p):return f'{p[0]:.3f},{p[1]:.3f}'
def svgcurve(p,closed=False):
 p=np.asarray(p,dtype=float);p=p[np.r_[True,np.linalg.norm(np.diff(p,axis=0),axis=1)>1e-7]]
 if len(p)<4:return 'M'+fmt(p[0])+'L'+fmt(p[-1]),2
 tck,u=splprep(p.T,s=len(p)*(.22 if closed else .07)**2,per=closed,k=3)
 t,c,k=tck;bs=BSpline(t,np.array(c).T,k);der=bs.derivative();br=np.unique(t[(t>=0)&(t<=1)])
 d='M'+fmt(bs(br[0]));n=1
 for a,b in zip(br[:-1],br[1:]):
  h=(b-a)/3;q0=bs(a);q3=bs(b)
  d+='C'+fmt(q0+h*der(a))+' '+fmt(q3-h*der(b))+' '+fmt(q3);n+=1
 return d+('Z' if closed else ''),n
sil,silanchors=svgcurve(cont,True)
def add(name,p,stroke=.7):
 d,n=svgcurve(p);groups[name].append(f'<path d="{d}" stroke-width="{stroke:.2f}"/>');counts[name]=counts.get(name,0)+n;curves.append(np.asarray(p))
def spline(points):
 a=np.array(points,float);return CubicSpline(a[:,0],a[:,1],bc_type='natural')
def pchip(points):
 a=np.array(points,float);return PchipInterpolator(a[:,0],a[:,1])
MID=511.0
frac=np.array([.06,.17,.33,.5,.67,.83,.94])
# Neck/shoulder/chest/waist cross sections are designed from the source.
TL=spline([(200,466),(215,463),(235,430),(255,386),(275,349),(295,352),(325,371),(365,379),(410,385),(455,394),(500,402),(525,405),(560,399),(595,395)])
TR=lambda t:1022-TL(t)
sagT=spline([(200,0),(230,3),(270,9),(310,6),(350,8),(395,5),(450,2),(520,1),(560,3),(595,5)])
# Torso longitudes meet two independently drawn leg surfaces at y=595.
uvals=np.sort(np.r_[frac/2,1-frac/2,.5])
for u in uvals:
 t=np.linspace(200,595,160);x=TL(t)+u*(TR(t)-TL(t));y=t+sagT(t)*(1-(2*u-1)**2)
 add('02_WIREFRAME_TORSO',np.c_[x,y])
for t in [200,215,232,250,270,291,313,337,362,389,416,442,469,496,522,548,574,595]:
 u=np.linspace(-.03 if t>=442 else 0,1.03 if t>=442 else 1,90);y=t+sagT(t)*(1-(2*u-1)**2);x=TL(y)+u*(TR(y)-TL(y))
 add('03_WIREFRAME_HEAD_NECK' if t<238 else '02_WIREFRAME_TORSO',np.c_[x,y])
# Lower torso cross sections span the pelvis as one continuous surface.
PL=spline([(595,395),(625,388),(655,381),(685,374),(715,369),(740,365)])
for t in [620,646,672,699,724,744]:
 u=np.linspace(-.035,1.035,100);y=t+5*(1-(2*u-1)**2);x=PL(np.minimum(y,744))+u*(1022-2*PL(np.minimum(y,744)))
 add('02_WIREFRAME_TORSO',np.c_[x,y])
# Central pelvis strand intentionally redrawn as one clean curve.
add('02_WIREFRAME_TORSO',[(511,600),(511,650),(511,700),(511,749)])
# Actual alpha intervals supply the leg silhouette rather than a new anatomy.
def intervals(y):
 xs=np.flatnonzero(alpha[int(np.clip(y,0,H-1))]);parts=np.split(xs,np.where(np.diff(xs)>1)[0]+1)
 return [(p[0],p[-1]) for p in parts if len(p)>5]
legY=[595,625,655,685,715,740,752,765,790,820,850,885,920,950,975,1000,1030,1060,1090,1120,1150,1180,1210,1240,1270,1300,1325,1340,1355,1370,1385,1400,1415,1430,1445,1455]
legs=[]
for side in (0,1):
 left=[];right=[]
 for y in legY:
  it=intervals(y)
  if y<752:
   lo=float(PL(min(y,740)));hi=1022-lo
   a,b=(lo,MID) if side==0 else (MID,hi)
  else:
   valid=[q for q in it if (q[0]+q[1])/2 < MID] if side==0 else [q for q in it if (q[0]+q[1])/2 > MID]
   a,b=max(valid,key=lambda q:q[1]-q[0])
  left.append((y,a));right.append((y,b))
 # Extend the last foot surface beyond toes and clip to the original silhouette.
 left += [(1470,left[-1][1]-2),(1490,left[-1][1]-2)]
 right += [(1470,right[-1][1]+2),(1490,right[-1][1]+2)]
 L=spline(left);R=spline(right);legs.append((L,R))
 # At start both legs share the torso's lower x positions.
 for u in frac:
  t=np.linspace(595,1488,400);x=L(t)+u*(R(t)-L(t))
  # The previous torso endpoint at each u had +sagT displacement. Blend
  # from that exact join over the first 25px to keep paths continuous.
  offset=5*(1-(2*(u/2 if side==0 else .5+u/2)-1)**2)
  y=t+np.maximum(0,1-(t-595)/30)*offset
  # Join uses torso reference at 595, then continues into the leg.
  ut=u/2 if side==0 else .5+u/2
  start=np.array([TL(595)+ut*(TR(595)-TL(595)),595+5*(1-(2*ut-1)**2)])
  add('05_WIREFRAME_LEGS_FEET',np.c_[x,y])
 # Curved cross sections, aligned from left leg to right leg.
 rings=[773,803,834,866,899,933,966,997,1029,1062,1096,1130,1164,1198,1231,1263,1294,1324,1345,1363,1381,1398,1413,1427,1439,1449,1457,1465,1472]
 for t in rings:
  u=np.linspace(-.10,1.10,110)
  sag=5 if t<1335 else -4
  y=t+sag*(1-(2*u-1)**2);x=L(y)+u*(R(y)-L(y))
  pp=np.c_[x,y];pp=pp[pp[:,0]<=MID] if side==0 else pp[pp[:,0]>=MID]
  add('05_WIREFRAME_LEGS_FEET',pp,.66)
# Upper arms and forearms, boundaries taken from source row samples.
armLeft=spline([(270,351),(285,335),(310,321),(340,317),(365,315),(395,305),(430,298),(465,296),(490,285),(520,276),(550,268),(580,265),(610,264),(640,262),(670,259),(695,257),(715,257)])
armRight=spline([(270,378),(285,374),(310,371),(340,374),(365,379),(395,384),(430,382),(465,374),(490,363),(520,353),(550,349),(580,341),(610,329),(640,314),(670,302),(695,299),(715,307)])
armRbase=armRight
# One shared shoulder seam avoids overlaying two independently drawn grids.
def armRight(y):
 y=np.asarray(y);blend=np.clip((y-370)/40,0,1);blend=blend*blend*(3-2*blend)
 return (1-blend)*TL(np.minimum(y,410))+blend*armRbase(y)
armLong={}
# Mirrored parameterization follows the source's nearly symmetric pose;
# both arms are clipped to the source alpha silhouette.
for side in (0,1):
 def armF(u,t):
  sag=3*(1-(2*u-1)**2);tilt=12*(u-.5)*np.tanh((t-530)/100)
  y=t+sag+tilt;x=armLeft(y)+u*(armRight(y)-armLeft(y))
  if side:x=1022-x
  return np.c_[x,y]
 for j,u in enumerate([.06,.18,.35,.5,.65,.82,.94]):
  t=np.linspace(280,697,180);pp=armF(u,t);origin=np.array([[350,273] if side==0 else [672,273]])
  armLong[(side,j)]=np.vstack([origin,pp])
 seamY=np.linspace(273,427,80);seamX=TL(seamY)
 if side:seamX=1022-seamX
 add('04_WIREFRAME_ARMS_HANDS',np.c_[seamX,seamY],.66)
 for t in [282,302,324,348,374,402,431,460,488,514,539,564,590,615,639,661,682,702]:
  add('04_WIREFRAME_ARMS_HANDS',armF(np.linspace(-.10,1.10 if t>=431 else 1,80),t),.66)
# Head surface has a deliberately smooth oval; ears remain separate detail.
HLbase=pchip([(23,510),(28,484),(40,468),(58,457),(80,452),(102,454),(125,458),(140,462),(201,511)])
def HL(y):
 y=np.asarray(y);lower=511-49*np.sqrt(np.maximum(0,1-((y-140)/61)**2))
 return np.where(y>=140,lower,HLbase(y))
for u in [.045,.12,.23,.36,.5,.64,.77,.88,.955]:
 theta=np.linspace(.025,np.pi,150);t=112-89*np.cos(theta);x=HL(t)+u*(1022-2*HL(t));add('03_WIREFRAME_HEAD_NECK',np.c_[x,t],.65)
for t in [31,46,65,86,108,131,153,173,189,198]:
 u=np.linspace(0,1,80);y=t+2.5*(1-(2*u-1)**2);l=HL(np.minimum(y,201));x=l+u*(1022-2*l)
 add('03_WIREFRAME_HEAD_NECK',np.c_[x,y],.65)
# A clean jaw boundary and source-based ear contours.
theta=np.linspace(0,np.pi,130);jaw=np.c_[511-49*np.cos(theta),140+61*np.sin(theta)];add('03_WIREFRAME_HEAD_NECK',jaw,.85)
for side in (0,1):
 for p in [[(454,112),(449,104),(446,110),(448,126),(454,140),(461,146)],[(453,116),(450,114),(452,128),(457,135)],[(449,121),(455,123),(458,131)]]:
  p=np.array(p,float)
  if side:p[:,0]=1022-p[:,0]
  add('03_WIREFRAME_HEAD_NECK',p,.62)
# A single smooth hand parameterization avoids overlapping palm/thumb grids.
# The original alpha silhouette clips the spaces between thumb and fingers.
handL=spline([(707,257),(725,256),(745,252),(765,252),(785,257),(800,264),(815,278),(830,298),(840,310)])
handR=spline([(707,305),(725,312),(745,317),(765,321),(785,323),(800,315),(815,310),(830,312),(840,316)])
def join_curves(a,b):
 p0=a[-1];p3=b[0];dist=np.linalg.norm(p3-p0);v=a[-1]-a[-3];v/=max(np.linalg.norm(v),1e-9);w=b[2]-b[0];w/=max(np.linalg.norm(w),1e-9)
 c1=p0+v*dist/3;c2=p3-w*dist/3;z=np.linspace(0,1,16)[:,None]
 q=(1-z)**3*p0+3*(1-z)**2*z*c1+3*(1-z)*z*z*c2+z**3*p3
 return np.vstack([a[:-1],q,b[1:]])
for side in (0,1):
 def handF(u,t):
  y=t+6*(u-.5)*np.exp(-((t-707)/35)**2)+2*(1-(2*u-1)**2)
  x=handL(y)+u*(handR(y)-handL(y))
  if side:x=1022-x
  return np.c_[x,y]
 for j,u in enumerate([.06,.18,.35,.5,.65,.82,.94]):
  pp=handF(u,np.linspace(707,839,130));pp=join_curves(armLong[(side,j)],pp)
  add('04_WIREFRAME_ARMS_HANDS',pp,.64)
 for t in [715,726,738,750,762,774,786,798,810,821,831]:
  add('04_WIREFRAME_ARMS_HANDS',handF(np.linspace(-.15,1.15,90),t),.6)
# Genuine vector body/contour plus reconstructed grid, globally clipped.
header=f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="{W}" height="{H}" viewBox="0 0 {W} {H}">'
header+='<title>Male mannequin — redrawn smooth wireframe</title><desc>Source-based body silhouette with newly designed smooth grid. Not an exact reconstruction of the AI-generated line topology.</desc>'
def group(name,body,attrs=''):return f'<g id="{name}" inkscape:groupmode="layer" inkscape:label="{name}" {attrs}>{body}</g>'
body=group('01_BODY_SILHOUETTE',f'<path d="{sil}" fill="#cdcdcd"/>')
wire=''.join(group(n,''.join(groups[n]),'fill="none" stroke="#242424" stroke-linecap="round" stroke-linejoin="round"') for n in groups if n.startswith(('02','03','04','05')))
outline=group('06_OUTER_CONTOUR',f'<path d="{sil}" fill="none" stroke="#242424" stroke-width="0.9" stroke-linejoin="round"/>')
clip=f'<defs><clipPath id="body_clip"><path d="{sil}"/></clipPath></defs>'
for name,content in [('Male_Body_Master',body+clip+'<g clip-path="url(#body_clip)">'+wire+'</g>'+outline),('Male_Wireframe_Only',clip+'<g clip-path="url(#body_clip)">'+wire+'</g>'+outline),('Male_Silhouette_Only',body)]:
 (OUT/(name+'.svg')).write_text(header+content+'</svg>')
 cairosvg.svg2png(url=str(OUT/(name+'.svg')),write_to=str(ROOT/(name+'.png')),scale=3)
Image.open(ROOT/'Male_Body_Master.png').save(OUT/'Male_Vector_Preview.png')
def white(im):
 b=Image.new('RGBA',im.size,'white');b.alpha_composite(im.convert('RGBA'));return b.convert('RGB')
vec=white(Image.open(ROOT/'Male_Body_Master.png')).resize((W,H),Image.Resampling.LANCZOS)
canvas=Image.new('RGB',(W*2,H+45),'white');canvas.paste(source,(0,45));canvas.paste(vec,(W,45));d=ImageDraw.Draw(canvas);d.text((15,15),'Original AI-generated raster',fill='black');d.text((W+15,15),'New smooth grid — original body silhouette',fill='black');canvas.save(OUT/'Male_Vector_Comparison.png')
vecFull=white(Image.open(ROOT/'Male_Body_Master.png'));wireFull=white(Image.open(ROOT/'Male_Wireframe_Only.png'))
regions=[('Head and neck',(438,15,584,250)),('Shoulder and torso',(310,240,712,600)),('Left hand',(245,695,325,837)),('Right hand',(692,695,777,837)),('Pelvis and thighs',(355,590,668,920)),('Knees',(365,930,650,1075)),('Feet',(320,1335,701,1482))]
qa=Image.new('RGB',(1800,len(regions)*430),'white');d=ImageDraw.Draw(qa)
for i,(name,box) in enumerate(regions):
 d.text((15,i*430+10),name+' | source / redrawn with fill / redrawn wireframe',fill='black')
 for j,im2 in enumerate([source,vecFull,wireFull]):
  factor=1 if j==0 else 3;bb=tuple(int(v*factor) for v in box);p=im2.crop(bb);scale=min(570/p.width,390/p.height);p=p.resize((int(p.width*scale),int(p.height*scale)),Image.Resampling.LANCZOS);qa.paste(p,(j*600+15,i*430+30))
qa.save(OUT/'Male_Vector_QA.png')
# Full-frame overlay checks silhouette; the grid has deliberately changed.
newAlpha=np.array(Image.open(ROOT/'Male_Silhouette_Only.png').resize((W,H),Image.Resampling.LANCZOS))[:,:,3]>128
intersection=(alpha&newAlpha).sum();union=(alpha|newAlpha).sum();iou=float(intersection/union)
overlay=np.ones((H,W,3),np.uint8)*255;overlay[alpha]=[230,80,80];overlay[newAlpha]=[80,190,210];overlay[alpha&newAlpha]=[170,170,170];Image.fromarray(overlay).save(OUT/'Male_Silhouette_Overlay.png')
# Inspect large torso detail without the fill.
box=(355*3,590*3,668*3,920*3);wireFull.crop(box).save(OUT/'Male_Pelvis_Detail.png')
metrics={'source_size':[W,H],'wireframe_paths':sum(len(v) for k,v in groups.items() if k.startswith(('02','03','04','05'))),'wireframe_anchors':sum(counts.values()),'silhouette_anchors':silanchors,'silhouette_IoU':iou,'regional_path_counts':{k:len(v) for k,v in groups.items() if v},'visible_rasters':0}
(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2))
