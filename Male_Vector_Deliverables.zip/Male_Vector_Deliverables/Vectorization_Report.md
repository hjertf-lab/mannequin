# Vectorization report

Source: supplied PNG, 1024 × 1536 pixels, from Male -front för codex.zip.

## Delivered geometry

The three SVG files contain actual editable paths; there are no embedded raster images. Master has the requested six named groups, an independent closed gray silhouette, regional centerline strokes, an outer contour, and vector clipping. Background is transparent. The reference layer was omitted. All artwork retains source coordinates, pose, and proportions; no generic mesh or generated anatomy was substituted.

Wireframe: 7,081 paths, approximately 23,119 endpoint anchors. Silhouette: one closed path, approximately 2,768 anchors. Master includes the silhouette geometry again for its outer contour and non-visible clipping path. Bezier control handles are additional editable coordinates, not included in these anchor counts. Paths split at skeleton branches/intersections; a complete grid strand can therefore comprise several paths.

## Method

White-composite the supplied PNG for analysis; upsample 2× with cubic interpolation; threshold at 215/255; discard only components smaller than four upsampled pixels. Extract the largest external body contour without adding anatomy or morphological gap-closing. Skeletonize the observed linework. Trace every graph edge once, suppress redundant diagonal shortcuts, then fit cubic Bezier curves at 0.30 source-pixel sample tolerance; short segments retain line geometry. Bound control points to avoid spline excursions. Use uniform 0.75-pixel dark strokes and a neutral #c9c9c9 fill. Regional groups are assigned by spatial location; boundary paths may require regrouping for highly selective editing.

## Validation and visual review

Rendered all SVGs with CairoSVG. Parsed all three SVGs as XML and confirmed paths exist and raster image elements are absent. Reviewed enlarged head/neck, both hands, thighs/knees, and feet. Initial curve excursions were corrected; an initial threshold that lost faint lines was increased and outputs rerendered. Current QA and comparison correspond to the final revision.

At source resolution, 96.54% of original dark pixels (gray <170) are within one pixel of rendered wireframe dark pixels; 97.81% of rendered dark pixels are within one pixel of original dark pixels. Source-to-vector distance, 95th percentile: 1.00 pixels. These measure spatial alignment, not guaranteed topology, silhouette equivalence, or production approval. Differences in thickness and antialiasing affect the numbers.

Comparison shows original versus gray-filled master. QA includes enlarged originals, vector renders, and red/cyan alignment overlays. Full-frame overlay: red denotes source-only darkness, cyan vector-only darkness, black coincidence. Preview is a 2048 × 3072 transparent render, not additional source detail.

## Remaining imperfections and manual work

This is an automatically traced editable master requiring manual finishing before production use, not a certified exact reconstruction. Source rasterization limits recoverable detail. Small staircase effects and short segments remain at dense intersections, fingers, toes, ears, jaw/neck and crotch. Close parallel strokes can merge in the raster/skeleton, and faint or disconnected source segments may remain fragmented. In those regions, inspect the supplied QA and original; manually join only visually verified strands and adjust tangents/weights. The outer contour follows the observed raster edge and retains small raster-scale irregularities. Uniform strokes do not reproduce every original variation in darkness/weight. Node density is intentionally conservative to prioritize alignment. No missing geometry was silently invented.

SVG uses standard paths, cubic curves, groups, and vector clipPath. Adobe Illustrator opening/editing and layer import have NOT been tested because Illustrator is unavailable. Verify grouping, clipping and stroke appearance in Illustrator before production acceptance; named groups may import as groups rather than native Illustrator layers.

## Reproduction

Python scripts, dependency versions and source PNG are included in the ZIP under pipeline/. Run `python3 -m pip install -r requirements.txt`, then `python3 vectorize.py` and `python3 finalize.py` from the pipeline directory. Outputs go to output/. The finalization script derives its directory from its own path.
