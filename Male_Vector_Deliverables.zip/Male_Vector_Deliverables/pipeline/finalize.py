from pathlib import Path
from PIL import Image
import numpy as np,json,zipfile,shutil
r=Path(__file__).resolve().parent;o=r/'output';m=json.loads((o/'metrics.json').read_text())
src=Image.open(r/'source.png').convert('RGBA');white=Image.new('RGBA',src.size,'white');white.alpha_composite(src);a=np.array(white.convert('L'))
v=Image.open(r/'Male_Wireframe_Only.png').convert('RGBA');b=Image.new('RGBA',v.size,'white');b.alpha_composite(v);b=np.array(b.convert('L').resize(src.size,Image.Resampling.LANCZOS));overlay=np.stack([b,a,a],axis=-1);Image.fromarray(overlay).save(o/'Male_Vector_Overlay.png')
report=f'''# Vectorization report

Source: supplied PNG, 1024 × 1536 pixels, from Male -front för codex.zip.

## Delivered geometry

The three SVG files contain actual editable paths; there are no embedded raster images. Master has the requested six named groups, an independent closed gray silhouette, regional centerline strokes, an outer contour, and vector clipping. Background is transparent. The reference layer was omitted. All artwork retains source coordinates, pose, and proportions; no generic mesh or generated anatomy was substituted.

Wireframe: {m['wireframe_paths']:,} paths, approximately {m['wireframe_anchors']:,} endpoint anchors. Silhouette: one closed path, approximately {m['silhouette_anchors']:,} anchors. Master includes the silhouette geometry again for its outer contour and non-visible clipping path. Bezier control handles are additional editable coordinates, not included in these anchor counts. Paths split at skeleton branches/intersections; a complete grid strand can therefore comprise several paths.

## Method

White-composite the supplied PNG for analysis; upsample 2× with cubic interpolation; threshold at 215/255; discard only components smaller than four upsampled pixels. Extract the largest external body contour without adding anatomy or morphological gap-closing. Skeletonize the observed linework. Trace every graph edge once, suppress redundant diagonal shortcuts, then fit cubic Bezier curves at 0.30 source-pixel sample tolerance; short segments retain line geometry. Bound control points to avoid spline excursions. Use uniform 0.75-pixel dark strokes and a neutral #c9c9c9 fill. Regional groups are assigned by spatial location; boundary paths may require regrouping for highly selective editing.

## Validation and visual review

Rendered all SVGs with CairoSVG. Parsed all three SVGs as XML and confirmed paths exist and raster image elements are absent. Reviewed enlarged head/neck, both hands, thighs/knees, and feet. Initial curve excursions were corrected; an initial threshold that lost faint lines was increased and outputs rerendered. Current QA and comparison correspond to the final revision.

At source resolution, {m['source_within_1px_vector_percent']:.2f}% of original dark pixels (gray <170) are within one pixel of rendered wireframe dark pixels; {m['vector_within_1px_source_percent']:.2f}% of rendered dark pixels are within one pixel of original dark pixels. Source-to-vector distance, 95th percentile: {m['source_to_vector_distance_p95_px']:.2f} pixels. These measure spatial alignment, not guaranteed topology, silhouette equivalence, or production approval. Differences in thickness and antialiasing affect the numbers.

Comparison shows original versus gray-filled master. QA includes enlarged originals, vector renders, and red/cyan alignment overlays. Full-frame overlay: red denotes source-only darkness, cyan vector-only darkness, black coincidence. Preview is a 2048 × 3072 transparent render, not additional source detail.

## Remaining imperfections and manual work

This is an automatically traced editable master requiring manual finishing before production use, not a certified exact reconstruction. Source rasterization limits recoverable detail. Small staircase effects and short segments remain at dense intersections, fingers, toes, ears, jaw/neck and crotch. Close parallel strokes can merge in the raster/skeleton, and faint or disconnected source segments may remain fragmented. In those regions, inspect the supplied QA and original; manually join only visually verified strands and adjust tangents/weights. The outer contour follows the observed raster edge and retains small raster-scale irregularities. Uniform strokes do not reproduce every original variation in darkness/weight. Node density is intentionally conservative to prioritize alignment. No missing geometry was silently invented.

SVG uses standard paths, cubic curves, groups, and vector clipPath. Adobe Illustrator opening/editing and layer import have NOT been tested because Illustrator is unavailable. Verify grouping, clipping and stroke appearance in Illustrator before production acceptance; named groups may import as groups rather than native Illustrator layers.

## Reproduction

Python scripts, dependency versions and source PNG are included in the ZIP under pipeline/. Run `python3 -m pip install -r requirements.txt`, then `python3 vectorize.py` and `python3 finalize.py` from the pipeline directory. Outputs go to output/. The finalization script derives its directory from its own path.
'''
(o/'Vectorization_Report.md').write_text(report)
# Keep reproduction relocatable.
q=(r/'finalize.py').read_text().replace("r=Path(__file__).resolve().parent","r=Path(__file__).resolve().parent")
(r/'finalize.py').write_text(q)
(r/'requirements.txt').write_text('numpy==2.3.5\nscipy==1.17.0\nPillow==12.3.0\nscikit-image==0.26.0\nopencv-python-headless==5.0.0.93\nCairoSVG==2.9.1\n')
with zipfile.ZipFile(r/'Male_Vector_Deliverables.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(o.iterdir()):z.write(f,'Male_Vector_Deliverables/'+f.name)
 for name in ['source.png','vectorize.py','finalize.py','requirements.txt']:z.write(r/name,'Male_Vector_Deliverables/pipeline/'+name)
print('Packaged:',r/'Male_Vector_Deliverables.zip')
print('Bytes:',(r/'Male_Vector_Deliverables.zip').stat().st_size)
