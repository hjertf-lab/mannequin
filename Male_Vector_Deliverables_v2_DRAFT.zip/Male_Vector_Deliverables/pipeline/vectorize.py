from pathlib import Path
import numpy as np, cv2, json, cairosvg
from PIL import Image, ImageDraw
from skimage.morphology import skeletonize
from scipy import ndimage as ndi
import xml.etree.ElementTree as ET
ROOT=Path(__file__).parent; OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
im=Image.open(ROOT/'source.png').convert('RGBA'); bg=Image.new('RGBA',im.size,'white'); bg.alpha_composite(im); src=bg.convert('RGB'); gray=np.array(src.convert('L')); H,W=gray.shape
scale=2
up=cv2.resize(gray,None,fx=scale,fy=scale,interpolation=cv2.INTER_CUBIC)
mask=ndi.gaussian_filter(up.astype(float),0.65)<235
# Close only subpixel raster breaks; no long-range strand reconstruction.
closedmask=ndi.binary_closing(mask,structure=np.ones((3,3)))
yy,xx=np.indices(mask.shape)
detail=(yy<250*scale)|(yy>1340*scale)|((yy>675*scale)&(yy<845*scale)&((xx<335*scale)|(xx>690*scale)))
mask=np.where(detail,up<215,closedmask)
# Remove isolated dust only; do not close gaps or invent connections.
lab,n=ndi.label(mask); sizes=np.bincount(lab.ravel()); mask &= sizes[lab]>=4
contours,_=cv2.findContours(mask.astype('uint8'),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
cont=max(contours,key=cv2.contourArea)
body=np.zeros_like(up,dtype='uint8'); cv2.drawContours(body,[cont],-1,1,-1)
sk=skeletonize(mask)
ys,xs=np.where(sk); pixels=set(zip(xs.tolist(),ys.tolist()))
adj={}
for x,y in pixels:
 a=[]
 for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
  q=(x+dx,y+dy)
  if q in pixels:
   if dx and dy and ((x+dx,y) in pixels or (x,y+dy) in pixels): continue
   a.append(q)
 adj[(x,y)]=a
visited=set(); chains=[]
def edge(a,b):return (a,b) if a<b else (b,a)
def walk(a,b):
 chain=[a,b];visited.add(edge(a,b))
 while len(adj[b])==2:
  c=next(q for q in adj[b] if q!=a)
  if edge(b,c) in visited: break
  visited.add(edge(b,c));chain.append(c);a,b=b,c
 return chain
for a in sorted(adj):
 if len(adj[a])!=2:
  for b in adj[a]:
   if edge(a,b) not in visited: chains.append(walk(a,b))
for a in sorted(adj):
 for b in adj[a]:
  if edge(a,b) not in visited: chains.append(walk(a,b))
# Collapse only very small duplicate arcs between identical junctions.
# Larger mesh cells and close independent strands are retained.
byends={}
for ch in chains:byends.setdefault(tuple(sorted((ch[0],ch[-1]))),[]).append(ch)
clean=[];collapsed=0
for key,cc in byends.items():
 if len(cc)==2 and max(len(c) for c in cc)<36 and key[0]!=key[1]:
  pp=[]
  for c in cc:
   if c[0]!=key[0]:c=c[::-1]
   p=np.array(c,dtype=float);t=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))];t/=t[-1]
   pp.append(np.column_stack([np.interp(np.linspace(0,1,24),t,p[:,k]) for k in (0,1)]))
  if np.max(np.linalg.norm(pp[0]-pp[1],axis=1))<5:
   avg=(pp[0]+pp[1])/2
   clean.append([tuple(q) for q in avg]);collapsed+=1;continue
 clean.extend(cc)
chains=clean
# Chain smoothing preserves shared endpoints while suppressing raster-scale steps.
# Pair opposing chains through each junction to retain longer editable strands.
endmap={}
for i,ch in enumerate(chains):
 for side,q in enumerate((ch[0],ch[-1])):endmap.setdefault(q,[]).append((i,side))
pair={}
for q,ends in endmap.items():
 candidates=[]
 for j,e in enumerate(ends):
  i,side=e; ch=chains[i] if side==0 else chains[i][::-1]
  if len(ch)<3:continue
  v=np.array(ch[min(len(ch)-1,12)])-np.array(q);v=v/max(np.linalg.norm(v),1e-9)
  for f in ends[j+1:]:
   k,ss=f
   if k==i:continue
   cc=chains[k] if ss==0 else chains[k][::-1]
   if len(cc)<3:continue
   w=np.array(cc[min(len(cc)-1,12)])-np.array(q);w=w/max(np.linalg.norm(w),1e-9)
   dot=np.dot(v,w)
   if dot<-.86:candidates.append((dot,e,f))
 used=set()
 for _,e,f in sorted(candidates):
  if e not in used and f not in used:pair[e]=f;pair[f]=e;used.update([e,f])
merged=[];seen=set()
starts=[(i,s) for i in range(len(chains)) for s in (0,1) if (i,s) not in pair]
starts += [(i,0) for i in range(len(chains))]
for i,side in starts:
 if i in seen:continue
 cc=[]
 while i not in seen:
  seen.add(i);ch=chains[i] if side==0 else chains[i][::-1]
  cc+=ch if not cc else ch[1:]
  nxt=pair.get((i,1-side))
  if nxt is None:break
  i,side=nxt
 merged.append(cc)
chains=merged

def smooth(p,closed=False):
 if len(p)<5:return p
 ds=np.linalg.norm(np.diff(p,axis=0),axis=1);t=np.r_[0,np.cumsum(ds)]
 tt=np.linspace(0,t[-1],max(3,int(t[-1]*2)+1))
 pp=np.column_stack([np.interp(tt,t,p[:,k]) for k in (0,1)])
 x,y=np.mean(p,axis=0)
 fine=closed or y<250 or y>1340 or (675<y<845 and (x<335 or x>690))
 out=ndi.gaussian_filter1d(pp,1.2 if fine else 3.2,axis=0,mode='wrap' if closed else 'nearest')
 if not closed:
  # Keep junctions exactly connected; taper the smoothing near them.
  blend=np.minimum(np.minimum(tt,tt[-1]-tt)/2,1)[:,None]
  out=pp+(out-pp)*blend
 return out

def fit(p,tol=.52):
 if len(p)<4:return [('L',q) for q in p[1:]]
 t=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
 if t[-1]<1e-8:return [('L',p[-1])]
 t/=t[-1];u=1-t
 # Solve handle lengths along endpoint tangents: prevents unconstrained loops.
 v=p[min(4,len(p)-1)]-p[0];v/=max(np.linalg.norm(v),1e-9)
 w=p[max(0,len(p)-5)]-p[-1];w/=max(np.linalg.norm(w),1e-9)
 b1=3*u*u*t;b2=3*u*t*t
 base=(u**3+b1)[:,None]*p[0]+(t**3+b2)[:,None]*p[-1]
 A=np.stack([b1[:,None]*v,b2[:,None]*w],axis=2).reshape(-1,2)
 from scipy.optimize import nnls
 lens=nnls(A,(p-base).ravel())[0]
 c=np.array([p[0]+lens[0]*v,p[-1]+lens[1]*w])
 pred=base+b1[:,None]*(c[0]-p[0])+b2[:,None]*(c[1]-p[-1])
 err=np.linalg.norm(pred-p,axis=1);k=int(err.argmax())
 if err[k]<=tol and max(lens)<max(2,np.linalg.norm(p[-1]-p[0])*1.2):return [('C',c[0],c[1],p[-1])]
 k=max(1,min(len(p)-2,k));return fit(p[:k+1],tol)+fit(p[k:],tol)
def pt(p):return f'{p[0]:.3f},{p[1]:.3f}'
def path(p,closed=False):
 p=smooth(p,closed);seg=fit(p);d='M'+pt(p[0]);anchors=1
 for s in seg:
  d+=s[0]+' '.join(pt(x) for x in s[1:]);anchors+=1
 return d+('Z' if closed else ''),anchors
silp=cont[:,0,:].astype(float)/scale
# Closed contour fit uses the same tolerance, preserving fingers and toes.
sild,sila=path(np.vstack([silp,silp[0]]),True)
groups={n:[] for n in ['02_WIREFRAME_TORSO','03_WIREFRAME_HEAD_NECK','04_WIREFRAME_ARMS_HANDS','05_WIREFRAME_LEGS_FEET']}
anchors=0
for chain in chains:
 p=np.array(chain,dtype=float)/scale
 if len(p)<2:continue
 x,y=np.mean(p,axis=0)
 if y<238:g='03_WIREFRAME_HEAD_NECK'
 elif (y<840 and (x<395 or x>630)):g='04_WIREFRAME_ARMS_HANDS'
 elif y>748:g='05_WIREFRAME_LEGS_FEET'
 else:g='02_WIREFRAME_TORSO'
 d,a=path(p);anchors+=a
 # Preserve heavier outlines/details through a local width estimate.
 widths=2*ndi.map_coordinates(ndi.distance_transform_edt(mask),np.array(chain).T[::-1],order=0)/scale if False else None
 groups[g].append(d)
header=f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="{W}" height="{H}" viewBox="0 0 {W} {H}">'
# Inkscape's standard namespace provides named layers to compatible editors.
header=header.replace('http://www.inkscape.org/namespaces/inkscape','http://www.inkscape.org/namespaces/inkscape')
def group(name,content,attrs=''):
 return f'<g id="{name}" inkscape:groupmode="layer" inkscape:label="{name}" {attrs}>{content}</g>'
sil=group('01_BODY_SILHOUETTE',f'<path d="{sild}" fill="#c9c9c9"/>')
wire=''.join(group(n,''.join(f'<path d="{d}"/>' for d in paths),'fill="none" stroke="#202020" stroke-width="0.75" stroke-linecap="round" stroke-linejoin="round"') for n,paths in groups.items())
contour=group('06_OUTER_CONTOUR',f'<path d="{sild}" fill="none" stroke="#202020" stroke-width="0.7" stroke-linejoin="round"/>')
for name,content in [('Male_Body_Master',sil+f'<defs><clipPath id="body_clip"><path d="{sild}"/></clipPath></defs><g clip-path="url(#body_clip)">'+wire+'</g>'+contour),('Male_Wireframe_Only',wire+contour),('Male_Silhouette_Only',sil)]:
 (OUT/(name+'.svg')).write_text(header+content+'</svg>')
for name in ['Male_Body_Master','Male_Wireframe_Only','Male_Silhouette_Only']:
 cairosvg.svg2png(url=str(OUT/(name+'.svg')),write_to=str(ROOT/(name+'.png')),scale=2)
Image.open(ROOT/'Male_Body_Master.png').save(OUT/'Male_Vector_Preview.png')
# Comparison and QA use white backing only for inspection.
def white(im):
 a=Image.new('RGBA',im.size,'white');a.alpha_composite(im.convert('RGBA'));return a.convert('RGB')
vec=white(Image.open(ROOT/'Male_Body_Master.png')).resize((W,H),Image.Resampling.LANCZOS)
wireim=white(Image.open(ROOT/'Male_Wireframe_Only.png')).resize((W,H),Image.Resampling.LANCZOS)
cmp=Image.new('RGB',(W*2,H+40),'white');cmp.paste(src,(0,40));cmp.paste(vec,(W,40));dr=ImageDraw.Draw(cmp);dr.text((20,12),'ORIGINAL — 1024 x 1536',fill='black');dr.text((W+20,12),'EDITABLE VECTOR — gray silhouette',fill='black');cmp.save(OUT/'Male_Vector_Comparison.png')
regions=[('Head and neck',(435,15,585,255)),('Left hand',(240,675,332,843)),('Right hand',(692,675,780,843)),('Thighs and knees',(350,730,670,1075)),('Feet',(320,1340,705,1485))]
qa=Image.new('RGB',(1800,2100),'white');dr=ImageDraw.Draw(qa)
for i,(name,box) in enumerate(regions):
 y=i*410;dr.text((15,y+8),name+' | original / vector / alignment (red=source, cyan=vector)',fill='black')
 a=src.crop(box);b=vec.crop(box);aa=np.array(src.convert('L').crop(box));bb=np.array(wireim.convert('L').crop(box));ov=np.ones((*aa.shape,3),dtype=np.uint8)*255;ov[:,:,0]=bb;ov[:,:,1]=aa;ov[:,:,2]=aa
 for j,c in enumerate([a,b,Image.fromarray(ov)]):
  c.thumbnail((570,375)); # followed by enlargement using preserved aspect
  fac=min(570/c.width,375/c.height);c=c.resize((int(c.width*fac),int(c.height*fac)),Image.Resampling.LANCZOS);qa.paste(c,(j*600+15,y+30))
qa.save(OUT/'Male_Vector_QA.png')
a=np.array(src.convert('L'))<170;b=np.array(wireim.convert('L'))<170
dta=ndi.distance_transform_edt(~a);dtb=ndi.distance_transform_edt(~b)
metrics={'collapsed_small_duplicate_arcs':collapsed,'wireframe_paths':sum(map(len,groups.values())),'wireframe_anchors':anchors,'silhouette_anchors':sila,'source_dark_pixels':int(a.sum()),'source_within_1px_vector_percent':float((dtb[a]<=1).mean()*100),'vector_within_1px_source_percent':float((dta[b]<=1).mean()*100),'source_to_vector_distance_p95_px':float(np.percentile(dtb[a],95)),'groups':{k:len(v) for k,v in groups.items()}}
(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2))
# Structural checks: all geometry is editable; no embedded images.
for f in OUT.glob('*.svg'):
 r=ET.parse(f).getroot();assert not list(r.iter('{http://www.w3.org/2000/svg}image'));assert list(r.iter('{http://www.w3.org/2000/svg}path'))
